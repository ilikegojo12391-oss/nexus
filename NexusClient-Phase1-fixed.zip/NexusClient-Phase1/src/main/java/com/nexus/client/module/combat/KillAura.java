package com.nexus.client.module.combat;

import com.nexus.client.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

import java.util.Comparator;

public class KillAura extends Module {
    private double range = 3.0;
    private boolean players = true;
    private boolean mobs = false;
    private int cooldownTicks = 10;
    private int timer = 0;

    public KillAura() {
        super("Kill Aura", "Combat");
    }

    @Override
    public void tick(MinecraftClient client) {
        if (client.player == null || client.world == null || client.interactionManager == null) return;
        if (timer > 0) {
            timer--;
            return;
        }

        LivingEntity target = client.world.getEntitiesByClass(
                LivingEntity.class,
                client.player.getBoundingBox().expand(range),
                entity -> isValidTarget(client.player, entity)
        ).stream().min(Comparator.comparingDouble(client.player::distanceTo)).orElse(null);

        if (target == null) return;
        if (client.player.getAttackCooldownProgress(0.0f) < 0.90f) return;

        ClientPlayerInteractionManager manager = client.interactionManager;
        manager.attackEntity(client.player, target);
        client.player.swingHand(net.minecraft.util.Hand.MAIN_HAND);
        timer = cooldownTicks;
    }

    private boolean isValidTarget(PlayerEntity self, LivingEntity entity) {
        if (entity == self || !entity.isAlive() || entity.isRemoved()) return false;
        if (self.distanceTo(entity) > range) return false;

        if (entity instanceof PlayerEntity) return players;
        return mobs;
    }

    public double getRange() { return range; }
    public void setRange(double range) { this.range = Math.max(1.0, Math.min(6.0, range)); }
    public boolean isPlayers() { return players; }
    public void setPlayers(boolean players) { this.players = players; }
    public boolean isMobs() { return mobs; }
    public void setMobs(boolean mobs) { this.mobs = mobs; }
}
