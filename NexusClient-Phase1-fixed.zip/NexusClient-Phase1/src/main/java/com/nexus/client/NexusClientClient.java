package com.nexus.client;

import com.nexus.client.gui.ClickGuiScreen;
import com.nexus.client.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;

public class NexusClientClient implements ClientModInitializer {
    public static ModuleManager MODULES;
    private static boolean lastShiftRight = false;

    @Override
    public void onInitializeClient() {
        MODULES = new ModuleManager();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            MODULES.tick(client);

            // Shift + Right Click opens the ClickGUI.
            boolean combo = client.currentScreen == null
                    && client.options.sneakKey.isPressed()
                    && org.lwjgl.glfw.GLFW.glfwGetMouseButton(client.getWindow().getHandle(), org.lwjgl.glfw.GLFW.GLFW_MOUSE_BUTTON_RIGHT) == org.lwjgl.glfw.GLFW.GLFW_PRESS;

            if (combo && !lastShiftRight) {
                client.setScreen(new ClickGuiScreen());
            }
            lastShiftRight = combo;
        });
    }

    public static MinecraftClient mc() {
        return MinecraftClient.getInstance();
    }
}
