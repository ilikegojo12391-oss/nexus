package com.nexus.client.module;

import net.minecraft.client.MinecraftClient;

public abstract class Module {
    private final String name;
    private final String category;
    private boolean enabled;

    protected Module(String name, String category) {
        this.name = name;
        this.category = category;
    }

    public final String getName() { return name; }
    public final String getCategory() { return category; }
    public final boolean isEnabled() { return enabled; }

    public final void toggle() {
        setEnabled(!enabled);
    }

    public final void setEnabled(boolean enabled) {
        if (this.enabled == enabled) return;
        this.enabled = enabled;
        if (enabled) onEnable();
        else onDisable();
    }

    protected void onEnable() {}
    protected void onDisable() {}

    public void tick(MinecraftClient client) {}
}
