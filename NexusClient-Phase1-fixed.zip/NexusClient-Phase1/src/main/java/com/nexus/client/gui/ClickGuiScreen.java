package com.nexus.client.gui;

import com.nexus.client.NexusClientClient;
import com.nexus.client.module.Module;
import com.nexus.client.module.combat.KillAura;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class ClickGuiScreen extends Screen {
    private final int panelWidth = 310;
    private final int panelHeight = 250;
    private int left;
    private int top;

    public ClickGuiScreen() {
        super(Text.literal("Nexus Client"));
    }

    @Override
    protected void init() {
        left = (width - panelWidth) / 2;
        top = (height - panelHeight) / 2;

        Module killAura = NexusClientClient.MODULES.get("Kill Aura");
        if (killAura == null) return;

        addDrawableChild(ButtonWidget.builder(
                Text.literal(killAura.isEnabled() ? "Kill Aura: ON" : "Kill Aura: OFF"),
                button -> {
                    killAura.toggle();
                    button.setMessage(Text.literal(killAura.isEnabled() ? "Kill Aura: ON" : "Kill Aura: OFF"));
                }
        ).dimensions(left + 20, top + 55, 270, 28).build());

        addDrawableChild(ButtonWidget.builder(
                Text.literal("Close"),
                button -> close()
        ).dimensions(left + 20, top + 200, 270, 28).build());

        addDrawableChild(ButtonWidget.builder(
                Text.literal("Range: 3.0"),
                button -> {
                    if (killAura instanceof KillAura aura) {
                        double next = aura.getRange() >= 6.0 ? 2.0 : aura.getRange() + 0.5;
                        aura.setRange(next);
                        button.setMessage(Text.literal("Range: " + String.format("%.1f", aura.getRange())));
                    }
                }
        ).dimensions(left + 20, top + 95, 270, 28).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);

        context.fill(left, top, left + panelWidth, top + panelHeight, 0xE5101018);
        context.fill(left, top, left + panelWidth, top + 35, 0xFF202030);

        context.drawCenteredTextWithShadow(
                textRenderer,
                Text.literal("NEXUS CLIENT"),
                left + panelWidth / 2,
                top + 12,
                0xFFFFFFFF
        );

        context.drawTextWithShadow(
                textRenderer,
                Text.literal("COMBAT"),
                left + 20,
                top + 40,
                0xFFAAAAAA
        );

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
