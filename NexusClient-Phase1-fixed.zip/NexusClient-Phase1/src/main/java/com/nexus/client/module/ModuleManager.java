package com.nexus.client.module;

import com.nexus.client.module.combat.KillAura;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();

    public ModuleManager() {
        modules.add(new KillAura());
    }

    public List<Module> getModules() {
        return Collections.unmodifiableList(modules);
    }

    public Module get(String name) {
        return modules.stream()
                .filter(m -> m.getName().equalsIgnoreCase(name))
                .findFirst()
                .orElse(null);
    }

    public void tick(MinecraftClient client) {
        for (Module module : modules) {
            if (module.isEnabled()) module.tick(client);
        }
    }
}
