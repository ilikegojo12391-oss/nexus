# Nexus Client — Phase 1

Minecraft Java 1.21.11 / Fabric / Java 21.

## Phase 1 features
- Shift + Right Click opens the ClickGUI.
- Kill Aura module.
- Player targeting.
- Optional mob targeting in code.
- Range setting (2.0–6.0).
- Attack cooldown check.
- Module manager architecture for future modules.

## Build
Use Java 21 and run:

```bash
./gradlew build
```

The compiled jar will be in:

`build/libs/`

Put the jar in the Fabric 1.21.11 `mods` folder together with Fabric API.

## Chromebook
If you are using ChromeOS, you can use a Linux development environment/IDE that supports Gradle and Java 21. The project itself is standard Gradle + Fabric Loom.

Fabric 1.21.11 is the final obfuscated Minecraft release; Yarn/Intermediary stop at 1.21.11, so this project intentionally targets 1.21.11.
